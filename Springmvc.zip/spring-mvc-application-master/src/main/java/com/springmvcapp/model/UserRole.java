package com.springmvcapp.model;

public enum UserRole {
    ADMIN, USER
}
